<!DOCTYPE html>
<html>
    <title>micro-polling</title>
    <link rel="stylesheet" type="text/css" href="micropollig.css"/>
    <!--
    <head>
      
      < Student Name: Ihab Mohamad >
      < Student ID: 200401862 > 
      
    </head>\
    -->
    
    
    <body>
      <header>
        <div class="header">
            <a href="#default" class="logo">MICRO-POLLING</a>
            <div class="header-right">
              <a class="h2">WELCOME</a>
            </div>
          </div> 
       
     </header>
     <section id=" navbar" style="float:right;width: 10%; background-color: rgb(176, 229, 229);">
      <a href="mainpage.html">Home page<br></a>
      <a href="signuppage.html">SignUp page<br></a>
      <a href="managpage.html">Poll Managment page<br></a>
      <a href="creatpage.html">Poll Create page<br></a>
      <a href="resultpage.html">Poll Result page<br></a>
    </section> 
    
    <section id="res" style="float: left; background-color: rgb(207, 207, 187);">
      <h1>Poll vote Page</h1>
    </section>


    <div class="vote";>
 
      <article>
        <h1 id="nameofcreater" style="text-align: center;"> Ihab Mohamad</h1>

               <h3 style="text-align: center; color: white;">Question: Do you find Cs-215 a hard class? </h3>
                     
               <label class="label" for='firstop' >
               <input type='radio'  id='firstop' /> Yes</label><br></br>
               <label class="label" for='secondop' >
               <input type='radio'  id='secondop' />  No</label><br></br>
               <label class="label" for='thirdop' >
               <input type='radio' id='thirdop' /> It's average</label>               
         <br></br>
         <Button> Submit Vote</Button>

       </article>

   </div>

    
    </body>