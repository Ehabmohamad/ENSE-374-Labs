function SignupForm(event) {

  var fnameInput = document.getElementById("email").value;
  var lnameInput = document.getElementById("email").value;
  var emailInput = document.getElementById("email").value;
  var unameInput = document.getElementById("email").value;
	var pswdInput = document.getElementById("password").value;
  var pswdrInput = document.getElementById("passwordr").value;

	
	var fnameMsg = document.getElementById("msg_fname");
  var lnameMsg = document.getElementById("msg_lname");
  var emailMsg = document.getElementById("msg_email");
  var unameMsg = document.getElementById("msg_uname");
	var pswdMsg = document.getElementById("msg_pswd");
  var pswdrMsg = document.getElementById("msg_pswdr");
	
	
	fnameMsg.innerHTML = "";
  lnameMsg.innerHTML = "";
  emailMsg.innerHTML = "";
  unameMsg.innerHTML = "";
	pswdMsg.innerHTML = ""; 
  pswdrMsg.innerHTML = ""; 

	
	
  var fnameCheck = /^[a-zA-Z_-]+$/; 
  var lnameCheck = /^[a-zA-Z_-]+$/; 
	var emailCheck = /^\w+@[a-zA-Z_]+?\.[a-zA-Z]{2,3}$/;
  var unameCheck = /^[a-zA-Z_-]+$/; 
	var pswdCheck = /^(\S*)?\d+(\S*)?$/;
	var pswdrCheck = /^(\S*)?\d+(\S*)?$/;
	
	var checkResult = true;
	
  if(fnameInput == null || fnameInput == "" )
	{
		fnameMsg.innerHTML = "Please enter first name.";
		checkResult = false;
	}

  if(lnameInput == null || lnameInput == "" )
	{
		lnameMsg.innerHTML = "Please enter last name.";
		checkResult = false;
	}
	if(emailInput == null || emailInput == "" || !emailCheck.test(emailInput))
	{
		emailMsg.innerHTML = "Please enter valid email.";
		checkResult = false;
	}
	if(unameInput == null || unameInput == "" )
	{
		unameMsg.innerHTML = "Please enter username.";
		checkResult = false;
	}
	if(pswdInput == null || pswdInput == "" || pswdInput.length < 8 || !pswdCheck.test(pswdInput))
	{
		pswdMsg.innerHTML = "Password must be at least 8 characters.";
		checkResult = false;
	}
  if(pswdrInput == null || pswdrInput == "" || pswdrInput.length < 8 || !pswdrCheck.test(pswdInput))
	{
		pswdrMsg.innerHTML = "Password must be at least 8 characters.";
		checkResult = false;
	}

	
	if(checkResult == false)
	{
		event.preventDefault();
	}

}



function SigninForm(event) {

    var valid = true;
    
    // TODO: Get field values for all form fields
    var elements = event.currentTarget;
    var email = elements[0].value; //Email
    var pswd = elements[1].value;//Password

  
    // javascript regular expressions (jre) to validate email, username and password
    // TODO: you may wish to change these to better match exercise requirements
    var regex_email = /^\w+@[a-zA-Z_]+?\.[a-zA-Z]{2,3}$/;
    var regex_pswd  = /^(\S*)?\d+(\S*)?$/;
  
  
    // Empty error message cells have been added to the table above the email, 
    // username, password and confirm password fields styled with red text color   
    // TODO: Get references to all error message cells and make sure they are empty before validating
    var msg_email = document.getElementById("msg_email");
    var msg_pswd = document.getElementById("msg_pswd");
    msg_email.innerHTML  = "";
    msg_pswd.innerHTML = "";
  
  
    //Variables for DOM Manipulation commands
    var textNode;
    var htmlNode;
  
  
    // if email is left empty or email format is wrong, add an error message to the matching cell.
    if (email == null || email == "") {
      textNode = document.createTextNode("Email address empty.");
      msg_email.appendChild(textNode);
      valid = false;
    } 
    else if (regex_email.test(email) == false) {
      textNode = document.createTextNode("Email address wrong format. example: username@somewhere.sth");
      msg_email.appendChild(textNode);
      valid = false;
    }
    else if (email.length > 60) {
      textNode = document.createTextNode("Email address too long. Maximum is 60 characters.");
      msg_email.appendChild(textNode);
      valid = false;
    }
  
   
    // TODO: add code to validate password - don't forget regex and length requirements
    if (pswd == null || pswd == "") {
        textNode = document.createTextNode("Password is empty.");
        msg_pswd.appendChild(textNode);
        valid = false;
    
      }
      else if (regex_pswd.test(pswd) == false) {
          textNode = document.createTextNode("Password is invalid. It must contain letters and at least one digit");
          msg_pswd.appendChild(textNode);
          valid = false;
        }
  
        else if (pswd.length != 8) {
          textNode = document.createTextNode("Password must be exactly 8 characters.");
          msg_pswd.appendChild(textNode);
          valid = false;
        }
  
  
  

    if(valid==false) {
      event.preventDefault(); // Normally, this is where this command should be
    }
  
  }

  function countChars1(obj){
    var maxLength = 100;
    var strLength = obj.value.length;
    
    if(strLength > maxLength){
        document.getElementById("charNum").innerHTML = '<span style="color: red;">'+strLength+' out of '+maxLength+' characters</span>';
    }else{
        document.getElementById("charNum").innerHTML = strLength+' out of '+maxLength+' characters';
    }
}
function countChars2(obj){
  var maxLength = 50;
  var strLength = obj.value.length;
  
  if(strLength > maxLength){
      document.getElementById("charNum1").innerHTML = '<span style="color: red;">'+strLength+' out of '+maxLength+' characters</span>';
  }else{
      document.getElementById("charNum1").innerHTML = strLength+' out of '+maxLength+' characters';
  }
}
function countChars3(obj){
  var maxLength = 50;
  var strLength = obj.value.length;
  
  if(strLength > maxLength){
      document.getElementById("charNum2").innerHTML = '<span style="color: red;">'+strLength+' out of '+maxLength+' characters</span>';
  }else{
      document.getElementById("charNum2").innerHTML = strLength+' out of '+maxLength+' characters';
  }
}
function countChars4(obj){
  var maxLength = 50;
  var strLength = obj.value.length;
  
  if(strLength > maxLength){
      document.getElementById("charNum3").innerHTML = '<span style="color: red;">'+strLength+' out of '+maxLength+' characters</span>';
  }else{
      document.getElementById("charNum3").innerHTML = strLength+' out of '+maxLength+' characters';
  }
}








function Poll_Creat(event) {

  var valid = true;
  
  var elements = event.currentTarget;
  var question = elements[0].value; 
 


  var regex_question = /^[a-zA-Z0-9_-]+$/;

  var msg_question = document.getElementById("msg_question");

  msg_question.innerHTML = "";
 
  var textNode;
  var htmlNode;


  if (question == null || question == "") {
    textNode = document.createTextNode("Your Poll Question is Empty.");
    msg_question.appendChild(textNode);
    valid = false;

  }
 

    else if (question.length > 100) {
      textNode = document.createTextNode("Your Poll Question is too long. Maximum is 100 Characters.");
      msg_question.appendChild(textNode);
      valid = false;
    }
    
    
    if(valid==false) {
      event.preventDefault(); // Normally, this is where this command should be
    }

}