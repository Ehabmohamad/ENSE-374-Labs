
<?php   include_once ('signuppage.php');?>

<?php
$validate = true;
$error = "";
$reg_fname = "/^[a-zA-Z_-]+$/"; 
$reg_lname = "/^[a-zA-Z_-]+$/"; 
$reg_Email = "/^\w+@[a-zA-Z_]+?\.[a-zA-Z]{2,3}$/"; 
$reg_uname = "/^[a-zA-Z_-]+$/"; 
$reg_Pswd = "/^(\S*)?\d+(\S*)?$/";
$reg_Pswdr = "/^(\S*)?\d+(\S*)?$/";
$fname = "";
$lname = "";
$email = "";
$uname = "";
$date = "mm/dd/yyyy";



if (isset($_POST["submitted"]) && $_POST["submitted"]) {
    $fname = trim($_POST["fname"]);
    $lname = trim($_POST["lname"]);
    $email = trim($_POST["email"]);
    $uname = trim($_POST["uname"]);
    $password = trim($_POST["password"]);
    $passwordr = trim($_POST["passwordr"]);

    try{   
    $db = new PDO ("mysql:host=localhost; dbname=imi582", "imi582", "s215!" );

    $fnameLen = strlen($fname);
    $fnameMatch = preg_match($reg_fname, $fname);
    if($fname == null || $fname == "" || $fnameLen > 40 || $fnameMatch == false){
      $validate = false;
      $error .= "Invalid screen name.\n<br />";
    }

    $lnameLen = strlen($lname);
    $lnameMatch = preg_match($reg_lname, $lname);
    if($lname == null || $lname == "" || $lnameLen > 40 || $lnameMatch == false){
      $validate = false;
      $error .= "Invalid screen name.\n<br />";
    }


    $emailMatch = preg_match($reg_Email, $email);
    if($email == null || $email == "" || $emailMatch == false) {
        $validate = false;
        $error .= "Invalid email address.\n<br />";
    }
    $q1 = "SELECT COUNT(*) FROM Users WHERE email = '$email'";
    $count = $db->query($q1)->fetchColumn(); 
    if($count > 0) {
        $validate = false;
        $error .= "Email address already exists.\n";
    }
    $unameLen = strlen($uname);
    $unameMatch = preg_match($reg_uname, $uname);
    if($uname == null || $uname == "" || $unameLen > 40 || $unameMatch == false){
      $validate = false;
      $error .= "Invalid screen name.\n<br />";
    }
    $pswdLen = strlen($password);
    $pswdMatch = preg_match($reg_Pswd, $password);
    if($password == null || $password == "" || $pswdLen < 8 || $pswdMatch == false) {
        $validate = false;
        $error .= "Invalid password.\n<br />";
    }
    
    
    $bdayMatch = preg_match($reg_Bday, $date);
    if($date == null || $date == "" || $bdayMatch == false) {
        $validate = false;
        $error .= "Invalid birthday.\n<br />";
    }

    
    $q1 = "SELECT * FROM User3 WHERE email = '$email'";
    $r1 = $db->query($q1);

    if($r1->$num_rows > 0) {
        $validate = false;

    } else {
      $fnamelMatch = preg_match($reg_fname, $fname);
        if($fname == null || $fname == "" || $fnamelMatch == false) {
          $validate = false;
        }
          $lnamelMatch = preg_match($reg_lname, $lname);
        if($lname == null || $lname == "" || $lnamelMatch == false) {
          $validate = false;
        }
        $emailMatch = preg_match($reg_Email, $email);
        if($email == null || $email == "" || $emailMatch == false) {
            $validate = false;
        }
        $unamelMatch = preg_match($reg_uname, $uname);
        if($uname == null || $uname == "" || $unamelMatch == false) {
          $validate = false;
        }
        $pswdLen = strlen($password);
        $pswdMatch = preg_match($reg_Pswd, $password);
        if($password == null || $password == "" || $pswdrLen < 8 || $pswdMatch == false) {
            $validate = false;
        }
        $pswdrLen = strlen($passwordr);
        $pswdrMatch = preg_match($reg_Pswdr, $passwordr);
        if($passwordr == null || $passwordr == "" || $pswdrLen < 8 || $pswdrMatch == false) {
            $validate = false;
        }

      }

    
    

    if($validate == true) {

      $dateFormat = date("Y-m-d", strtotime($date));
        
        $q2 = "INSERT INTO User3 (fname, lname, email, uname, DOB, password)
        VALUES ( '$fname', '$lname', '$email', '$uname', '$dateFormat', '$password')";
         
         
        
         if ($db->query($q2) === TRUE) 
         {
       echo "New record created successfully";
       } else {
        echo "Error: " . $q2 . "<br>" . $conn->$error;
       }
       
       $r2 = $db->exec($q2);
       if ($r2 != false) {
        header("Location: mainpage.php");
        $r2 = null;
        $db = null;
        exit();

    } else {
        $r2 = null;
        $validate = false;
        $error .= "Trouble adding new user to database!\n<br />";
    }   
  
  
  if ($validate == false) {
    $error .= "Signup failed.";
  }
  $db = null;
    }
} catch (PDOException $e) {
  echo "PDO Error >> " . $e->getMessage() . "\n<br />";
}
}

echo $error;

?>



<!DOCTYPE html>
<html>

<head>
    
    <title>sig-up Website</title>
    <link rel="stylesheet" type = "text/css" href="micropollig.css" />
    <script type="text/javascript" src="styel.js"> </script>
  <body>
    <header>
        <div class="header">
            <a href="#default" class="logo">MICRO-POLLING</a>
            <div class="header-right">
              <a class="h2">WELCOME</a>
            </div>
          </div> 
       
     </header>
     <section id=" navbar" style="float:right;width: 10%; background-color: rgb(176, 229, 229);">
      <a href="mainpage.html">Home page<br></a>
      <a href="managpage.html">Poll Managment page<br></a>
      <a href="votepage.html">Poll Vote page<br></a>
      <a href="creatpage.html">Poll Create page<br></a>
      <a href="resultpage.html">Poll Result page<br></a>
    </section> 
    <br><br><br><br><br><br><br><br>
     <div class="SignUp">
      <img src="index.png" class="index">
      <h1>Creat Your Account</h1>
      <form id="Signup" method="get" action="managpage.php">
          <p>FIRST NAME <br><br>
            <label id="msg_fname" class="err_msg" style="color: red;"></label>
          </p>
          <input type="FIRST NAME" id = "fname" name = "fname" placeholder="FERST NAME" style="color:rgb(3, 3, 3);  text-align: center;
  width: 80%;
  padding: 15px;
  margin: 5px 0 22px 0;
  background: #f1f1f1;" >
          <p>LAST NAME <br><br>
            <label id="msg_lname" class="err_msg"style="color: red;"></label>
          </p>
          <input type="LAST NAME"  id = "lname" name = "lname" placeholder="LAST NAME" style="color:rgb(0, 0, 0)">
          <p>EMAIL <br><br>
            <label id="msg_email" class="err_msg" style="color: red;"></label>
           </p>
          <input type="email"  id = "email" name = "email" placeholder="YOUR EMAIL" style="color:rgb(0, 0, 0);  text-align: center;
  width: 80%;
  padding: 15px;
  margin: 5px 0 22px 0;
  background: #f1f1f1;">
          <p>USERNAME  <br><br>
            <label id="msg_uname" class="err_msg" style="color: red;"></label>
          </p>
          <input type="username"  id = "uname" name = "uname" placeholder="USERNAME" style="color:rgb(0, 0, 0)">
          <p>PASSWORD  <br><br>
            <label id="msg_pswd" class="err_msg" style="color: red;"></label></td>
          </p>
          <input type="password"  id = "password" name = "password" placeholder="YOUR PASSWORD" style="color:rgb(0, 0, 0)">
          <p>CONFIRM PASSWORD  <br><br>
            <label id="msg_pswdr" class="err_msg" style="color: red;"></label></td>
          </p>
          <input type="password" id = "passwordr" name = "passwordr" placeholder="REWRITE PASSWORD" style="color:rgb(0, 0, 0)">
          
          <button type="submit" class="signupbtn" value="signup">Sign Up</button>
          <br><br><br>
          <a href="mainpage.html">Main Page</a>
      
      </form>
      <script type="text/javascript" src="signup.js"></script>
    </div>
    <footer ><div class="footer">
      <em>Created by Ihab Mohamad</em>
      <br>
      <p>©Ihab_mohamad.2021</p>
      </div>
    </footer>
    </body>
</head>

</html>