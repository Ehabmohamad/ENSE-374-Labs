<?php   include_once ('signuppage.php');?>

<?php
$validate = true;
$error = "";
$msg_question = "/^[a-zA-Z0-9_-]+$/";
$question = "";
$answer1 = "";
$answer2 = "";
$answer3 = "";
$date = "mm/dd/yyyy";
$date2 = "mm/dd/yyyy";



if (isset($_POST["submitted"]) && $_POST["submitted"]) {
    $question = trim($_POST["question"]);
    $answer1 = trim($_POST["answer1"]);
    $answer2 = trim($_POST["answer2"]);
    $answer3 = trim($_POST["answer3"]);
    $date = trim($_POST["open_date_time"]);
    $date = trim($_POST["close_date_time"]);
    

    try{   
    $db = new PDO ("mysql:host=localhost; dbname=imi582", "imi582", "s215!" );


    if ($db->connect_error) {
      die ("Connection failed: " . $db->connect_error);
         }
    
    // new note
     

         
  
  if($validate == true) {
    $dateFormat = date("Y-m-d", strtotime($date));

    $q2 = "INSERT INTO Polls_table (question, answer1, answer2, answer3, DOB)
    VALUES ( '$question', '$answer1', '$answer2', '$answer3', '$dateFormat')";

     if ($db->query($q) === TRUE) 
     {
     echo "New record created successfully";
     } 
     else {
      echo "Error: " . $q . "<br>" . $conn->error;
     }
     
      $r = $db->query($q);
      
      if ($r === true) {
          header("Location: resultpage.php");
          $r = null;
        $db = null;
        exit();
      }

          else 
            {
      
      $error = ("Please enter your quetion and answers.");
      $r = null;
      $db = null;
      exit();
       }
  } 
      else 
        {
    $error = ("You must enter quetion and answers");
    }

  }catch (PDOException $e) {
    echo "PDO Error >> " . $e->getMessage() . "\n<br />";
  }
  
}


echo $error;

?>

<!DOCTYPE html>
<html>
    <title>micro-polling</title>
    <link rel="stylesheet" type="text/css" href="micropollig.css"/>
    <script type="text/javascript" src="styel.js"> </script>
    <!--
    <head>
      
      < Student Name: Ihab Mohamad >
      < Student ID: 200401862 > 
      
    </head>\
    -->
    
    
    <body>
      <header>
        <div class="header">
            <a href="#default" class="logo">MICRO-POLLING</a>
            <div class="header-right">
              <a class="h2">WELCOME</a>
            </div>
          </div> 
       
     </header>
     <section id=" navbar" style="float:right;width: 10%; background-color: rgb(176, 229, 229);">
      <a href="mainpage.html">Home page<br></a>
      <a href="signuppage.html">SignUp page<br></a>
      <a href="managpage.html">Poll Managment page<br></a>
      <a href="votepage.html">Poll Vote page<br></a>
      <a href="resultpage.html">Poll Result page<br></a>
    </section> 
    
    <section id="res" style="float: left; background-color: rgb(207, 207, 187);">
      <h1>Poll create Page</h1>
    </section>

     <div class="create";>
      <article>
         <article >

          
          <h1 id="nameofcreater" style="text-align: center;"> create your Poll </h1>
          <form id="PollCreat" method="get" action="http://www.webdev.cs.uregina.ca/~imi582/assignment2/managpage.html">

               <h3>Enter Poll Topic and Quation:
                <div class="textBox1">
                  <label id="msg_question" class="err_msg" style="color: red;"></label>
                  <input onkeyup="countChars1(this)"  id = "question" name="question" type="text"  placeholder="Enter first Choice"><br>
                  <p id="charNum">0 characters</p>
                  
                </div>
               </h3>

               <div class = "textBox">    
                
               <p  style="color: white;" >Enter Your First Answer </p>
               <input  onkeyup="countChars2(this)"  id = " answer1" name="answer1" type="text"  placeholder="Enter first Answer"><br>
              
              <p id="charNum1">0 characters</p>
              

              
               
               <p style="color: white;">Enter Your second Answer </p>
               <input onkeyup="countChars3(this)" id = " answer2" name="answer2"  type="text"  placeholder="Enter second Answer"><br>
               <p id="charNum2">0 characters</p>
               
               
            
               <p style="color: white;">Enter Your third Answer </p>
               <input onkeyup="countChars4(this)" id = " answer3" name="answer3" type="text" placeholder="Enter third Answer"><br>
               <p id="charNum3">0 characters</p>
               
             

            
               <!-- <form id="PollCreatTime" method="get" action="http://www.webdev.cs.uregina.ca/~imi582/assignment2/managpage.html"> -->
               <label for="open_date_time">Open Date and Time:</label>
               <input type="date"  class="poll_answers_input" id = "open_date_time" name="open_date_time" style="height: 40px; width: 30%; color:rgb(5, 5, 5);
               background-color: hsla(0, 0%, 100%, 0.541);" />
               <!-- <label id="msg_date" class="err_msg" style="color: red;"></label> -->
               
               <input type="time" class="poll_answers_input" id = "open_date_time" name="open_date_time" style="height: 40px;width: 20%; color:rgb(5, 5, 5);
               background-color: hsla(0, 0%, 100%, 0.541);" />
               <!-- <label id="msg_time" class="err_msg" style="color: red;"></label> -->
               <br> <br>
               
               <label for="close_date_time">Close Date and Time:</label>
               <input type="date" class="poll_answers_input" id = "close_date_time" name="close_date_time" style="height: 40px; width: 30%; color:rgb(5, 5, 5);
               background-color: hsla(0, 0%, 100%, 0.541);" />
               <!-- <label id="msg_date" class="err_msg" style="color: red;"></label> -->
               
               <input type="time" class="poll_answers_input" id = "close_date_time" name="close_date_time" style="height: 40px; width: 20%; color:rgb(5, 5, 5);
               background-color: hsla(0, 0%, 100%, 0.541);"/>
               <!-- <label id="msg_time" class="err_msg" style="color: red;"></label> -->
                <!-- </form> -->
          
               
              </div>
              <br> 
              <button type="submit" class="signupbtn" value="signup">Sign Up</button>
              </form>
              
         </article>
         </article>
        
        </div>
        <script type="text/javascript" src="creat.js"> </script>


    </body>