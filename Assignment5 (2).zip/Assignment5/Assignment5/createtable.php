<?php

try {
    $conn = new PDO("mysql:host=localhost; dbname=imi582", "imi583", "Cs215!");

    $sql = "CREATE TABLE User3 (
        user_id INT NOT NULL AUTO_INCREMENT,
        fname VARCHAR(255) NOT NULL,
        lname VARCHAR(255) NOT NULL,
        email VARCHAR(255) NOT NULL,
        uname VARCHAR(255) NOT NULL,
        DOB DATE,
        avatar VARCHAR(255),
        password VARCHAR(30) NOT NULL,
        PRIMARY KEY (user_id)
    )";

$sql = "CREATE TABLE Polls_table (
    polls_id INT NOT NULL AUTO_INCREMENT,
    user_id INT,
    question VARCHAR(255) NOT NULL,
    created_dt DATETIME,
    open_dt DATETIME,
    close_dt DATETIME,
    PRIMARY KEY (polls_id),
    FOREIGN KEY (user_id) REFERENCES User3 (user_id)
)";

$sql = "CREATE TABLE Ans_table (
    ans_id INT NOT NULL AUTO_INCREMENT,
    polls_id INT,
    ans VARCHAR(255) NOT NULL,
    PRIMARY KEY (ans_id),
    FOREIGN KEY (polls_id) REFERENCES Polls_table (polls_id)
)";

$sql = "CREATE TABLE Votes_table (
    votes_id INT NOT NULL AUTO_INCREMENT,
    ans_id INT,
    votes_dt DATETIME,
    PRIMARY KEY (votes_id),
    FOREIGN KEY (ans_id) REFERENCES Ans_table (ans_id)
)"; 
   

$db->exec($sql);
echo "Table User created successfully!\n<br />";
} catch (PDOException $e) {
echo "PDO Error >> " . $e->getMessage() . "\n<br />";
}

$db = null;

?>