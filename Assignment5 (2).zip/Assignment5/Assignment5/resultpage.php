<!DOCTYPE html>
<html>
    <title>micro-polling</title>
    <link rel="stylesheet" type="text/css" href="micropollig.css"/>
    <!--
    <head>
      
      < Student Name: Ihab Mohamad >
      < Student ID: 200401862 > 
      
    </head>\
    -->
    
    
    <body>
      <header>
        <div class="header">
            <a href="#default" class="logo">MICRO-POLLING</a>
            <div class="header-right">
              <a class="h2">WELCOME</a>
            </div>
          </div> 
     </header>
     <section id=" navbar" style="float:right;width: 10%; background-color: rgb(176, 229, 229);">
      <a href="mainpage.html">Home page<br></a>
      <a href="signuppage.html">SignUp page<br></a>
      <a href="managpage.html">Poll Managment page<br></a>
      <a href="votepage.html">Poll Vote page<br></a>
      <a href="creatpage.html">Poll Create page<br></a>
   
    </section> 

      <section id="res" style="float: left; background-color: rgb(207, 207, 187);">
        <h1>Poll Result Page</h1>
      </section>
      <br><br><br><br>
      <div class="container">
          
          <table class="styled-table">
            <h1 style="text-align: left; padding-bottom:10px; font-size: large;" class="poll-name-res">Posted by Ihab Mohamad <p>Added on Date: July 5th, 2022</p></h1>
            
              <thead>
                  <tr>
                      <th>Question: What is the must used programing language?</th>
                  </tr>
              </thead>
              <tr>
                  <td>
                    <h2 class="option-1">C++:</h2>
                  </td>
                  <td>
                    <h3 class="vote1" style="color: rgb(71, 67, 197);">58%</h3>
                  </td>
              </tr>
              <tr>
                  <td class="rows">
                    <h2 class="option-2">Java:</h2>
                  </td>
                  <td>
                    <h3 class="vote2"style="color: rgb(71, 67, 197);">74%</h3>
                  </td>
              </tr>
              <tr>
                  <td>
                    <h2 class="option-3">javascript:</h2>
                  </td>
                  <td>
                    <h3 class="vote3"style="color: rgb(71, 67, 197);">66%</h3>
                  </td>
              </tr>
          </table>  
      </div>

  <footer><div class="footer">
      <em>Created by Ihab Mohamad</em>
      <br>
      <p>©Ihab_mohamad.2021</p>
      </div>
  </footer>
  

    </body>