<!DOCTYPE html>
<html>
    <title>micro-polling</title>
    <link rel="stylesheet" type="text/css" href="micropollig.css"/>
    <!--
    <head>
      
      < Student Name: Ihab Mohamad >
      < Student ID: 200401862 > 
      
    </head>\
    -->
    
    
<body>
      <header>
        <div class="header">
            <a href="#default" class="logo">MICRO-POLLING</a>
            <div class="header-right">
              <a class="h2">WELCOME</a>
            </div>
          </div> 
       
     </header>
     <section id=" navbar" style="float:right;width: 10%; background-color: rgb(176, 229, 229);">
      <a href="mainpage.php">Home page<br></a>
      <a href="signuppage.php">SignUp page<br></a>
      <a href="votepage.php">Poll Vote page<br></a>
      <a href="creatpage.php">Poll Create page<br></a>
      <a href="resultpage.php">Poll Result page<br></a>
    </section> 
    
    <section id="res" style="float: left; background-color: rgb(207, 207, 187);">
      <h1>Poll Management Page</h1>
    </section>
      <Br></br>

   <div class="manag">

          
            <h1 style="float: left; color: white;"> Ihab Mohamad <p style="color:white; float: right;padding: 20px; font-size: medium;">Added on Date: July 5th, 2022</p></h1>
               <br><br><br>
            <h3 style="text-align: center; color: rgb(255, 255, 255);">Question: what is your favourit class in school? </h3>
                
                <label class="label" for='option-1' >
                <input type='radio'  id='option-1' /> Math Classes</label>
                <div id="firBar"> 50%</div>
                <br></br>
                <label class="label" for='option-2' >
                <input type='radio' id='option-2' /> science classes</label>
                <div id="secBar"> 60% </div>
                <br></br>
                <label class="label" for='option-3' >
                <input type='radio' id='option-3' /> CS classes</label>
                <div class="fullBar" id="thirBar"> 85% </div>
         
   </div>
</body>