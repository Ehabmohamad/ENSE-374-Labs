<?php


$validate = true;
$error = "";

$reg_Email = "/^\w+@[a-zA-Z_]+?\.[a-zA-Z]{2,3}$/";
$reg_Pswd = "/^(\S*)?\d+(\S*)?$/";

$email = "";

	// check to see if the form was submitted
	if (isset($_POST["submitted"]) && $_POST["submitted"]) {
		// get the username and password and check that they aren't empty
		$email = trim($_POST["email"]);
		$pswd = trim($_POST["pswd"]);
		if (strlen($email) > 0 && strlen($pswd) > 0) {
			// load the database
			require_once("inc/db.php");
			try{
                $db = new PDO("mysql:host=localhost; dbname=imi582", "imi582", "Cs215!");
            } catch (PDOException $e) {
                throw new PDOException($e->getMessage(), (int)$e->getCode());
            }
		  
			//verify the username/password
		  	$q = "SELECT user_id, screenname FROM Users WHERE email = '$email' AND password = '$pswd'";
		  	$result = $db->query($q);
		  
		  	if ($row = $result->fetch()) 
              {
		  		// login successful
		  		session_start();
				$_SESSION["user_id"] = $row["user_id"];
				$_SESSION["screenname"] = $row["screenname"];
				header("Location: managpage.php");
				$db = null;
				exit();
			} 
            else 
              {
				// login unsuccessful
				$error = ("The username/password combination was incorrect.");
				$db = null;
			   }
		} 
        else 
          {
			$error = ("You must enter a non-blank username/password combination to login.");
		  }
	} 
      else 
       {
		$error = "";
	   }

?>

<!DOCTYPE html>
<html>
    <title>micro-polling</title>
    <link rel="stylesheet" type="text/css" href="micropollig.css"/>
    <script type="text/javascript" src="styel.js"> </script>
    <!--
    <head>
      
      < Student Name: Ihab Mohamad >
      < Student ID: 200401862 > 
      
    </head>\
    -->
    
    
    <body>
      <header>
        <div class="header">
            <a href="#default" class="logo">MICRO-POLLING</a>
            <div class="header-right">
              <a class="h2">WELCOME</a>
            </div>
          </div> 
       
     </header>
     <section id=" navbar" style="float:right;width: 10%; background-color: rgb(176, 229, 229);">
      <a href="signuppage.php">SignUp page<br></a>
      <a href="managpage.php">Poll Managment page<br></a>
      <a href="votepage.php">Poll Vote page<br></a>
      <a href="creatpage.php">Poll Create page<br></a>
      <a href="resultpage.php">Poll Result page<br></a>
    </section> 
    <br><br><br><br><br><br><br><br>

    <div style="color: rgb(50, 73, 162);" >
      
      </nav>
      <section id="recentactive">
        <h2>Recent Polling Active</h2>
        <ul>
            <li>1) Active :- 12 minutes age</li>
            <li>2) Active :- 24 minutes age</li>
            <li>3) Active :- 53 minutes age</li>
            <li>4) Active :- 2 days age</li>
            <li>5) Active :- week age</li>
            </ul>
        </section>

         <section id="sites">
          <h2>Links From Site</h2>
          <ul>
            <ol>
          <li><a href="creatpage.html">Poll Create page<br></a></li>
          <li> <a href="votepage.html">Poll Vote page<br></a>
            </li>
            </ol>
         </ul>
      
      </div>
      <aside id="login">
          <div class = "loginpage">
            <img src="index.png" class="index">
            <h1>LOGIN WITH YOUR ACCOUNT</h1>
            <form id="Signin" method="get" action="managpage.php">
                <P>USERNAME <br><br>
                  <label id="msg_email" class="err_msg" style="color: red;"></label>
                </P>
                <input  type="text" id = "email" name="email" placeholder="ENTER USERNAME" style="color:white">
                <P>PASSWORD <br><br>
                  <label  id="msg_pswd" class="err_msg" style="color: red;"></label>
                </P>
                <input type="password" id = "pswd" name="pswd" placeholder="ENTER PASSWORD" style="color:white" >
                
                <input type="submit"  value= "LOGIN">
                <input type="button" name="" value= "SignUp"  onclick="location.href='signuppage.html'">
                
            </form>
            <script type="text/javascript" src="styel-r.js"></script>
        </div>
         <br>
      </aside>
      <footer ><div class="footer">
        <em>Created by Ihab Mohamad</em>
        <br>
        <p>©Ihab_mohamad.2021</p>
        </div>
      </footer>
      
   
    </body>