
//TODO: use addEventListener() to add a function as the listener for form submit events. 
//      Use the submit event handler function we started for you in validate.js
document.getElementById("Signin").addEventListener("submit",SigninForm, false);
